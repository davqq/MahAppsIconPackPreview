﻿using Windows.UI.Xaml.Controls;

namespace MahApps.Metro.IconPacks
{
    public abstract class PathIconBase : PathIcon
    {
        protected abstract void UpdateData();
    }
}
