---
name: Icon update (request)
about: Suggest an icon update or request
title: ''
labels: Icon Update
assignees: punker76

---

**Icon update (request)**
Update <ICONS> to v<x.x.x>
<!-- Add <ICONS> from this <site>-->
